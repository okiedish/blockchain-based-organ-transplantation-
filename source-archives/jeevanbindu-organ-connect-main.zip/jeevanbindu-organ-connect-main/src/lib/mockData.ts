import { User, Hospital, Statistics, BlockchainRecord, MatchRequest, OrganType } from '@/types';

export const mockDonors: User[] = [
  {
    id: '1',
    aadharNumber: '****-****-1234',
    name: 'Rajesh Kumar',
    phone: '9876543210',
    role: 'donor',
    bloodGroup: 'A+',
    organType: ['kidney'],
    location: { state: 'Maharashtra', city: 'Mumbai', hospital: 'Apollo Hospital' },
    status: 'available',
    isVerified: true,
    blockchainTxHash: '0x1234...abcd',
    createdAt: new Date('2024-01-15'),
    updatedAt: new Date('2024-01-15'),
  },
  {
    id: '2',
    aadharNumber: '****-****-5678',
    name: 'Priya Sharma',
    phone: '9876543211',
    role: 'donor',
    bloodGroup: 'B+',
    organType: ['liver', 'cornea'],
    location: { state: 'Delhi', city: 'New Delhi', hospital: 'AIIMS' },
    status: 'matched',
    isVerified: true,
    blockchainTxHash: '0x5678...efgh',
    createdAt: new Date('2024-02-20'),
    updatedAt: new Date('2024-03-10'),
  },
  {
    id: '3',
    aadharNumber: '****-****-9012',
    name: 'Amit Patel',
    phone: '9876543212',
    role: 'donor',
    bloodGroup: 'O+',
    organType: ['heart'],
    location: { state: 'Gujarat', city: 'Ahmedabad', hospital: 'Sterling Hospital' },
    status: 'pending',
    isVerified: true,
    blockchainTxHash: '0x9012...ijkl',
    createdAt: new Date('2024-03-05'),
    updatedAt: new Date('2024-03-05'),
  },
];

export const mockRecipients: User[] = [
  {
    id: '4',
    aadharNumber: '****-****-3456',
    name: 'Sunita Devi',
    phone: '9876543213',
    role: 'recipient',
    bloodGroup: 'A+',
    organType: ['kidney'],
    location: { state: 'Maharashtra', city: 'Pune', hospital: 'Sahyadri Hospital' },
    status: 'pending',
    isVerified: true,
    blockchainTxHash: '0x3456...mnop',
    createdAt: new Date('2024-01-20'),
    updatedAt: new Date('2024-01-20'),
  },
  {
    id: '5',
    aadharNumber: '****-****-7890',
    name: 'Mohammed Ali',
    phone: '9876543214',
    role: 'recipient',
    bloodGroup: 'B+',
    organType: ['liver'],
    location: { state: 'Karnataka', city: 'Bangalore', hospital: 'Narayana Health' },
    status: 'matched',
    isVerified: true,
    blockchainTxHash: '0x7890...qrst',
    createdAt: new Date('2024-02-10'),
    updatedAt: new Date('2024-03-10'),
  },
];

export const mockHospitals: Hospital[] = [
  {
    id: 'h1',
    name: 'Apollo Hospital Mumbai',
    email: 'apollo.mumbai@hospital.org',
    location: { state: 'Maharashtra', city: 'Mumbai', address: 'Navi Mumbai, 400614' },
    isVerified: true,
    totalDonors: 150,
    totalRecipients: 200,
    successfulMatches: 45,
  },
  {
    id: 'h2',
    name: 'AIIMS Delhi',
    email: 'aiims.delhi@hospital.org',
    location: { state: 'Delhi', city: 'New Delhi', address: 'Ansari Nagar, 110029' },
    isVerified: true,
    totalDonors: 300,
    totalRecipients: 450,
    successfulMatches: 120,
  },
  {
    id: 'h3',
    name: 'Narayana Health Bangalore',
    email: 'narayana.blr@hospital.org',
    location: { state: 'Karnataka', city: 'Bangalore', address: 'Bommasandra, 560099' },
    isVerified: true,
    totalDonors: 200,
    totalRecipients: 280,
    successfulMatches: 75,
  },
];

export const mockStatistics: Statistics = {
  totalDonors: 15420,
  totalRecipients: 28650,
  successfulMatches: 4850,
  pendingMatches: 12340,
  verifiedHospitals: 1250,
  organsByType: {
    kidney: 5200,
    liver: 3100,
    heart: 890,
    lungs: 650,
    pancreas: 420,
    intestines: 180,
    cornea: 3500,
    skin: 980,
    bone: 350,
    'heart-valve': 150,
  },
  donorsByState: {
    Maharashtra: 2500,
    Delhi: 1800,
    Karnataka: 1600,
    'Tamil Nadu': 1400,
    Gujarat: 1200,
    'Uttar Pradesh': 2100,
    'West Bengal': 1100,
    Rajasthan: 900,
    Kerala: 850,
    'Madhya Pradesh': 780,
  },
};

export const mockBlockchainRecords: BlockchainRecord[] = [
  {
    txHash: '0x1234567890abcdef1234567890abcdef12345678',
    userId: '1',
    action: 'registration',
    timestamp: new Date('2024-01-15T10:30:00'),
    data: { organType: 'kidney', bloodGroup: 'A+' },
  },
  {
    txHash: '0xabcdef1234567890abcdef1234567890abcdef12',
    userId: '2',
    action: 'verification',
    timestamp: new Date('2024-02-20T14:45:00'),
    data: { verifiedBy: 'AIIMS Delhi' },
  },
  {
    txHash: '0x567890abcdef1234567890abcdef1234567890ab',
    userId: '5',
    action: 'match',
    timestamp: new Date('2024-03-10T09:15:00'),
    data: { donorId: '2', organType: 'liver' },
  },
];

export const mockMatchRequests: MatchRequest[] = [
  {
    id: 'm1',
    recipientId: '4',
    organType: 'kidney',
    bloodGroup: 'A+',
    status: 'pending',
    hospitalId: 'h1',
    createdAt: new Date('2024-03-01'),
    updatedAt: new Date('2024-03-01'),
  },
  {
    id: 'm2',
    recipientId: '5',
    donorId: '2',
    organType: 'liver',
    bloodGroup: 'B+',
    status: 'matched',
    hospitalId: 'h3',
    createdAt: new Date('2024-02-15'),
    updatedAt: new Date('2024-03-10'),
  },
];

export const indianStates = [
  'Andhra Pradesh', 'Arunachal Pradesh', 'Assam', 'Bihar', 'Chhattisgarh',
  'Goa', 'Gujarat', 'Haryana', 'Himachal Pradesh', 'Jharkhand', 'Karnataka',
  'Kerala', 'Madhya Pradesh', 'Maharashtra', 'Manipur', 'Meghalaya', 'Mizoram',
  'Nagaland', 'Odisha', 'Punjab', 'Rajasthan', 'Sikkim', 'Tamil Nadu',
  'Telangana', 'Tripura', 'Uttar Pradesh', 'Uttarakhand', 'West Bengal',
  'Delhi', 'Jammu and Kashmir', 'Ladakh'
];

export const organTypes: { value: OrganType; label: string }[] = [
  { value: 'kidney', label: 'Kidney' },
  { value: 'liver', label: 'Liver' },
  { value: 'heart', label: 'Heart' },
  { value: 'lungs', label: 'Lungs' },
  { value: 'pancreas', label: 'Pancreas' },
  { value: 'intestines', label: 'Intestines' },
  { value: 'cornea', label: 'Cornea' },
  { value: 'skin', label: 'Skin' },
  { value: 'bone', label: 'Bone' },
  { value: 'heart-valve', label: 'Heart Valve' },
];

export const bloodGroups = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
