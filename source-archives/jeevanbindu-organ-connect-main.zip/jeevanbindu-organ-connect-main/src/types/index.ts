export type UserRole = 'donor' | 'recipient' | 'hospital' | 'admin';

export type OrganType = 
  | 'kidney' 
  | 'liver' 
  | 'heart' 
  | 'lungs' 
  | 'pancreas' 
  | 'intestines' 
  | 'cornea' 
  | 'skin' 
  | 'bone' 
  | 'heart-valve';

export type BloodGroup = 'A+' | 'A-' | 'B+' | 'B-' | 'AB+' | 'AB-' | 'O+' | 'O-';

export type MatchStatus = 'available' | 'matched' | 'pending' | 'completed' | 'unavailable';

export interface User {
  id: string;
  aadharNumber: string;
  name: string;
  email?: string;
  phone: string;
  role: UserRole;
  bloodGroup: BloodGroup;
  organType: OrganType[];
  location: {
    state: string;
    city: string;
    hospital?: string;
  };
  status: MatchStatus;
  isVerified: boolean;
  blockchainTxHash?: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface BlockchainRecord {
  txHash: string;
  userId: string;
  action: 'registration' | 'match' | 'update' | 'verification';
  timestamp: Date;
  data: Record<string, unknown>;
}

export interface Hospital {
  id: string;
  name: string;
  email: string;
  location: {
    state: string;
    city: string;
    address: string;
  };
  isVerified: boolean;
  totalDonors: number;
  totalRecipients: number;
  successfulMatches: number;
}

export interface MatchRequest {
  id: string;
  recipientId: string;
  donorId?: string;
  organType: OrganType;
  bloodGroup: BloodGroup;
  status: MatchStatus;
  hospitalId: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface Statistics {
  totalDonors: number;
  totalRecipients: number;
  successfulMatches: number;
  pendingMatches: number;
  verifiedHospitals: number;
  organsByType: Record<OrganType, number>;
  donorsByState: Record<string, number>;
}
