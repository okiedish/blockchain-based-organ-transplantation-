import React, { createContext, useContext, useState, ReactNode } from 'react';
import { User, UserRole } from '@/types';
import { mockDonors, mockRecipients } from '@/lib/mockData';

interface AuthContextType {
  user: User | null;
  role: UserRole | null;
  isAuthenticated: boolean;
  login: (role: UserRole, userId?: string) => void;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [role, setRole] = useState<UserRole | null>(null);

  const login = (userRole: UserRole, userId?: string) => {
    setRole(userRole);
    
    if (userRole === 'donor') {
      const donor = userId ? mockDonors.find(d => d.id === userId) : mockDonors[0];
      setUser(donor || mockDonors[0]);
    } else if (userRole === 'recipient') {
      const recipient = userId ? mockRecipients.find(r => r.id === userId) : mockRecipients[0];
      setUser(recipient || mockRecipients[0]);
    } else if (userRole === 'hospital') {
      // Mock hospital user
      setUser({
        id: 'h1',
        aadharNumber: '',
        name: 'Apollo Hospital Mumbai',
        email: 'apollo.mumbai@hospital.org',
        phone: '022-12345678',
        role: 'hospital',
        bloodGroup: 'A+',
        organType: [],
        location: { state: 'Maharashtra', city: 'Mumbai' },
        status: 'available',
        isVerified: true,
        createdAt: new Date(),
        updatedAt: new Date(),
      });
    } else if (userRole === 'admin') {
      setUser({
        id: 'admin1',
        aadharNumber: '',
        name: 'System Administrator',
        email: 'admin@jeevanbindu.gov.in',
        phone: '011-12345678',
        role: 'admin',
        bloodGroup: 'A+',
        organType: [],
        location: { state: 'Delhi', city: 'New Delhi' },
        status: 'available',
        isVerified: true,
        createdAt: new Date(),
        updatedAt: new Date(),
      });
    }
  };

  const logout = () => {
    setUser(null);
    setRole(null);
  };

  return (
    <AuthContext.Provider value={{ user, role, isAuthenticated: !!user, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
