import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import Layout from '@/components/layout/Layout';
import { useAuth } from '@/contexts/AuthContext';
import DonorDashboard from '@/components/dashboard/DonorDashboard';
import RecipientDashboard from '@/components/dashboard/RecipientDashboard';
import HospitalDashboard from '@/components/dashboard/HospitalDashboard';
import AdminDashboard from '@/components/dashboard/AdminDashboard';

const Dashboard = () => {
  const { isAuthenticated, role, user } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/login');
    }
  }, [isAuthenticated, navigate]);

  if (!isAuthenticated || !role) {
    return null;
  }

  const getDashboardTitle = () => {
    switch (role) {
      case 'donor': return 'Donor Dashboard';
      case 'recipient': return 'Recipient Dashboard';
      case 'hospital': return 'Hospital Dashboard';
      case 'admin': return 'Government Admin Dashboard';
      default: return 'Dashboard';
    }
  };

  return (
    <>
      <Helmet>
        <title>{getDashboardTitle()} | JeevanBindu</title>
        <meta name="description" content={`Access your ${role} dashboard on JeevanBindu - India's National Organ Donation Registry.`} />
      </Helmet>

      <Layout hideFooter>
        <div className="min-h-screen bg-muted/30">
          {role === 'donor' && <DonorDashboard user={user!} />}
          {role === 'recipient' && <RecipientDashboard user={user!} />}
          {role === 'hospital' && <HospitalDashboard user={user!} />}
          {role === 'admin' && <AdminDashboard user={user!} />}
        </div>
      </Layout>
    </>
  );
};

export default Dashboard;
