import { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import Layout from '@/components/layout/Layout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { toast } from 'sonner';
import { 
  Fingerprint, 
  User, 
  CheckCircle, 
  ArrowRight, 
  ArrowLeft,
  Shield,
  Heart,
  Loader2
} from 'lucide-react';
import { indianStates, organTypes, bloodGroups } from '@/lib/mockData';

type RegistrationType = 'donor' | 'recipient';

const Register = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const [type, setType] = useState<RegistrationType>(
    (searchParams.get('type') as RegistrationType) || 'donor'
  );
  const [step, setStep] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [txHash, setTxHash] = useState('');

  // Form state
  const [aadharNumber, setAadharNumber] = useState('');
  const [otp, setOtp] = useState('');
  const [isAadharVerified, setIsAadharVerified] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    bloodGroup: '',
    organType: [] as string[],
    state: '',
    city: '',
    hospital: '',
    consent: false,
  });

  useEffect(() => {
    const typeParam = searchParams.get('type') as RegistrationType;
    if (typeParam === 'donor' || typeParam === 'recipient') {
      setType(typeParam);
    }
  }, [searchParams]);

  const handleAadharSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (aadharNumber.length !== 12) {
      toast.error('Please enter a valid 12-digit Aadhar number');
      return;
    }
    setIsLoading(true);
    // Simulate OTP sending
    await new Promise(resolve => setTimeout(resolve, 1500));
    setIsLoading(false);
    toast.success('OTP sent to your registered mobile number');
  };

  const handleOtpVerify = async (e: React.FormEvent) => {
    e.preventDefault();
    if (otp.length !== 6) {
      toast.error('Please enter a valid 6-digit OTP');
      return;
    }
    setIsLoading(true);
    // Simulate verification
    await new Promise(resolve => setTimeout(resolve, 2000));
    setIsLoading(false);
    setIsAadharVerified(true);
    setStep(2);
    toast.success('Aadhar verified successfully!');
  };

  const handleOrganToggle = (organ: string) => {
    setFormData(prev => ({
      ...prev,
      organType: prev.organType.includes(organ)
        ? prev.organType.filter(o => o !== organ)
        : [...prev.organType, organ]
    }));
  };

  const handleFinalSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.consent) {
      toast.error('Please accept the consent checkbox to proceed');
      return;
    }

    if (!formData.name || !formData.bloodGroup || formData.organType.length === 0 || !formData.state) {
      toast.error('Please fill all required fields');
      return;
    }

    setIsLoading(true);
    // Simulate blockchain transaction
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    // Generate mock transaction hash
    const mockTxHash = '0x' + Array.from({ length: 64 }, () => 
      Math.floor(Math.random() * 16).toString(16)
    ).join('');
    
    setTxHash(mockTxHash);
    setIsLoading(false);
    setShowSuccess(true);
  };

  return (
    <>
      <Helmet>
        <title>Register | JeevanBindu - Organ Donation Registry</title>
        <meta name="description" content={`Register as an organ ${type} with Aadhar verification on JeevanBindu - India's National Organ Donation Registry.`} />
      </Helmet>

      <Layout>
        <div className="min-h-screen py-12 px-4">
          <div className="container max-w-2xl mx-auto">
            {/* Header */}
            <div className="text-center mb-8">
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-4">
                <Shield className="w-4 h-4 text-primary" />
                <span className="text-sm font-medium text-primary">Aadhar Verified Registration</span>
              </div>
              <h1 className="text-3xl md:text-4xl font-bold mb-4">
                Register as {type === 'donor' ? 'Organ Donor' : 'Organ Recipient'}
              </h1>
              <p className="text-muted-foreground">
                Complete the verification process to join India's organ donation network
              </p>
            </div>

            {/* Type Selector */}
            <div className="flex gap-4 mb-8">
              <Button
                variant={type === 'donor' ? 'hero' : 'outline'}
                className="flex-1"
                onClick={() => setType('donor')}
              >
                <Heart className="w-4 h-4" />
                Register as Donor
              </Button>
              <Button
                variant={type === 'recipient' ? 'healthcare' : 'outline'}
                className="flex-1"
                onClick={() => setType('recipient')}
              >
                <User className="w-4 h-4" />
                Register as Recipient
              </Button>
            </div>

            {/* Progress Steps */}
            <div className="flex items-center justify-center gap-4 mb-8">
              <div className={`flex items-center gap-2 ${step >= 1 ? 'text-primary' : 'text-muted-foreground'}`}>
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${step >= 1 ? 'bg-primary text-primary-foreground' : 'bg-muted'}`}>
                  {isAadharVerified ? <CheckCircle className="w-5 h-5" /> : '1'}
                </div>
                <span className="text-sm font-medium hidden sm:inline">Aadhar Verification</span>
              </div>
              <div className="w-12 h-0.5 bg-border" />
              <div className={`flex items-center gap-2 ${step >= 2 ? 'text-primary' : 'text-muted-foreground'}`}>
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${step >= 2 ? 'bg-primary text-primary-foreground' : 'bg-muted'}`}>
                  2
                </div>
                <span className="text-sm font-medium hidden sm:inline">Personal Details</span>
              </div>
            </div>

            {/* Step 1: Aadhar Verification */}
            {step === 1 && (
              <div className="bg-card rounded-2xl border border-border p-8 shadow-lg animate-scale-in">
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                    <Fingerprint className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <h2 className="text-xl font-semibold">Aadhar Verification</h2>
                    <p className="text-sm text-muted-foreground">Enter your 12-digit Aadhar number</p>
                  </div>
                </div>

                <form onSubmit={!isAadharVerified ? handleAadharSubmit : handleOtpVerify} className="space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="aadhar">Aadhar Number</Label>
                    <Input
                      id="aadhar"
                      type="text"
                      placeholder="XXXX XXXX XXXX"
                      value={aadharNumber}
                      onChange={(e) => setAadharNumber(e.target.value.replace(/\D/g, '').slice(0, 12))}
                      className="text-lg tracking-widest"
                      disabled={aadharNumber.length === 12}
                    />
                  </div>

                  {aadharNumber.length === 12 && (
                    <div className="space-y-2 animate-slide-up">
                      <Label htmlFor="otp">Enter OTP</Label>
                      <Input
                        id="otp"
                        type="text"
                        placeholder="XXXXXX"
                        value={otp}
                        onChange={(e) => setOtp(e.target.value.replace(/\D/g, '').slice(0, 6))}
                        className="text-lg tracking-widest"
                      />
                      <p className="text-xs text-muted-foreground">
                        OTP sent to your Aadhar-linked mobile number
                      </p>
                    </div>
                  )}

                  <Button
                    type="submit"
                    className="w-full"
                    variant="hero"
                    size="lg"
                    disabled={isLoading || (aadharNumber.length !== 12 && otp.length !== 6)}
                  >
                    {isLoading ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        {aadharNumber.length === 12 && otp.length === 0 ? 'Sending OTP...' : 'Verifying...'}
                      </>
                    ) : (
                      <>
                        {aadharNumber.length < 12 ? 'Send OTP' : 'Verify OTP'}
                        <ArrowRight className="w-4 h-4" />
                      </>
                    )}
                  </Button>
                </form>
              </div>
            )}

            {/* Step 2: Personal Details */}
            {step === 2 && (
              <div className="bg-card rounded-2xl border border-border p-8 shadow-lg animate-scale-in">
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-12 h-12 rounded-xl bg-healthcare-teal/10 flex items-center justify-center">
                    <User className="w-6 h-6 text-healthcare-teal" />
                  </div>
                  <div>
                    <h2 className="text-xl font-semibold">{type === 'donor' ? 'Donor' : 'Recipient'} Details</h2>
                    <p className="text-sm text-muted-foreground">Fill in your personal and medical information</p>
                  </div>
                </div>

                <form onSubmit={handleFinalSubmit} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="name">Full Name *</Label>
                      <Input
                        id="name"
                        placeholder="As per Aadhar"
                        value={formData.name}
                        onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="phone">Phone Number *</Label>
                      <Input
                        id="phone"
                        type="tel"
                        placeholder="+91 XXXXX XXXXX"
                        value={formData.phone}
                        onChange={(e) => setFormData(prev => ({ ...prev, phone: e.target.value }))}
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="email">Email (Optional)</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="your@email.com"
                      value={formData.email}
                      onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Blood Group *</Label>
                      <Select
                        value={formData.bloodGroup}
                        onValueChange={(value) => setFormData(prev => ({ ...prev, bloodGroup: value }))}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select blood group" />
                        </SelectTrigger>
                        <SelectContent>
                          {bloodGroups.map((bg) => (
                            <SelectItem key={bg} value={bg}>{bg}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label>State *</Label>
                      <Select
                        value={formData.state}
                        onValueChange={(value) => setFormData(prev => ({ ...prev, state: value }))}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select state" />
                        </SelectTrigger>
                        <SelectContent>
                          {indianStates.map((state) => (
                            <SelectItem key={state} value={state}>{state}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="city">City *</Label>
                      <Input
                        id="city"
                        placeholder="Your city"
                        value={formData.city}
                        onChange={(e) => setFormData(prev => ({ ...prev, city: e.target.value }))}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="hospital">Preferred Hospital</Label>
                      <Input
                        id="hospital"
                        placeholder="Hospital name"
                        value={formData.hospital}
                        onChange={(e) => setFormData(prev => ({ ...prev, hospital: e.target.value }))}
                      />
                    </div>
                  </div>

                  <div className="space-y-3">
                    <Label>Organ Type(s) * {type === 'donor' ? '(You wish to donate)' : '(You need)'}</Label>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                      {organTypes.map((organ) => (
                        <div
                          key={organ.value}
                          className={`p-3 rounded-lg border cursor-pointer transition-all ${
                            formData.organType.includes(organ.value)
                              ? 'border-primary bg-primary/10 text-primary'
                              : 'border-border hover:border-primary/50'
                          }`}
                          onClick={() => handleOrganToggle(organ.value)}
                        >
                          <span className="text-sm font-medium">{organ.label}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="flex items-start gap-3 p-4 rounded-lg bg-muted">
                    <Checkbox
                      id="consent"
                      checked={formData.consent}
                      onCheckedChange={(checked) => 
                        setFormData(prev => ({ ...prev, consent: checked as boolean }))
                      }
                    />
                    <Label htmlFor="consent" className="text-sm leading-relaxed cursor-pointer">
                      I consent to share my details for organ matching purposes and understand that 
                      my information will be stored securely on the blockchain. I confirm all 
                      information provided is accurate.
                    </Label>
                  </div>

                  <div className="flex gap-4">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setStep(1)}
                      className="flex-1"
                    >
                      <ArrowLeft className="w-4 h-4" />
                      Back
                    </Button>
                    <Button
                      type="submit"
                      variant="hero"
                      className="flex-1"
                      disabled={isLoading}
                    >
                      {isLoading ? (
                        <>
                          <Loader2 className="w-4 h-4 animate-spin" />
                          Recording on Blockchain...
                        </>
                      ) : (
                        <>
                          Submit Registration
                          <ArrowRight className="w-4 h-4" />
                        </>
                      )}
                    </Button>
                  </div>
                </form>
              </div>
            )}
          </div>
        </div>

        {/* Success Dialog */}
        <Dialog open={showSuccess} onOpenChange={setShowSuccess}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <div className="mx-auto w-16 h-16 rounded-full bg-healthcare-green/20 flex items-center justify-center mb-4">
                <CheckCircle className="w-10 h-10 text-healthcare-green" />
              </div>
              <DialogTitle className="text-center text-2xl">Registration Successful!</DialogTitle>
              <DialogDescription className="text-center">
                Your registration has been verified and recorded on the blockchain.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="p-4 rounded-lg bg-muted">
                <p className="text-xs text-muted-foreground mb-1">Transaction Hash</p>
                <p className="text-xs font-mono break-all">{txHash}</p>
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Shield className="w-4 h-4 text-primary" />
                <span>Aadhar Verified</span>
                <CheckCircle className="w-4 h-4 text-healthcare-green ml-auto" />
              </div>
              <Button 
                className="w-full" 
                variant="hero"
                onClick={() => navigate('/login')}
              >
                Proceed to Login
                <ArrowRight className="w-4 h-4" />
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </Layout>
    </>
  );
};

export default Register;
