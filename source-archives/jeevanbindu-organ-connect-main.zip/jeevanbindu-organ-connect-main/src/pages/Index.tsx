import { Helmet } from 'react-helmet-async';
import Layout from '@/components/layout/Layout';
import HeroSection from '@/components/home/HeroSection';
import FeaturesSection from '@/components/home/FeaturesSection';
import RegistrationOptions from '@/components/home/RegistrationOptions';
import BlockchainSection from '@/components/home/BlockchainSection';

const Index = () => {
  return (
    <>
      <Helmet>
        <title>JeevanBindu - National Organ Donation Registry | Save Lives Today</title>
        <meta name="description" content="JeevanBindu is India's National Organ Donation Registry powered by blockchain technology. Register as a donor or recipient with Aadhar verification. Transparent, secure, and efficient organ matching." />
        <meta name="keywords" content="organ donation, India, blockchain, Aadhar verification, kidney donation, liver transplant, save lives, NOTTO" />
      </Helmet>
      
      <Layout>
        <HeroSection />
        <FeaturesSection />
        <RegistrationOptions />
        <BlockchainSection />
      </Layout>
    </>
  );
};

export default Index;
