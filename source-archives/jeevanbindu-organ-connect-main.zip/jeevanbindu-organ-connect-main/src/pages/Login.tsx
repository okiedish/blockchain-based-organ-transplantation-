import { useState } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import Layout from '@/components/layout/Layout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from 'sonner';
import { useAuth } from '@/contexts/AuthContext';
import { 
  Fingerprint, 
  Building2, 
  Shield, 
  ArrowRight, 
  Loader2,
  Eye,
  EyeOff,
  Lock
} from 'lucide-react';

const Login = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { login } = useAuth();
  
  const defaultTab = searchParams.get('type') === 'hospital' ? 'hospital' : 'individual';
  
  const [activeTab, setActiveTab] = useState(defaultTab);
  const [isLoading, setIsLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  
  // Individual login state
  const [aadharNumber, setAadharNumber] = useState('');
  const [otp, setOtp] = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const [userType, setUserType] = useState<'donor' | 'recipient'>('donor');
  
  // Hospital login state
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSendOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (aadharNumber.length !== 12) {
      toast.error('Please enter a valid 12-digit Aadhar number');
      return;
    }
    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 1500));
    setIsLoading(false);
    setOtpSent(true);
    toast.success('OTP sent to your registered mobile number');
  };

  const handleAadharLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (otp.length !== 6) {
      toast.error('Please enter a valid 6-digit OTP');
      return;
    }
    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 2000));
    login(userType);
    setIsLoading(false);
    toast.success('Login successful!');
    navigate('/dashboard');
  };

  const handleHospitalLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      toast.error('Please enter email and password');
      return;
    }
    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    // Check for admin login
    if (email.includes('admin')) {
      login('admin');
    } else {
      login('hospital');
    }
    
    setIsLoading(false);
    toast.success('Login successful!');
    navigate('/dashboard');
  };

  return (
    <>
      <Helmet>
        <title>Login | JeevanBindu - Organ Donation Registry</title>
        <meta name="description" content="Login to JeevanBindu - India's National Organ Donation Registry. Access your dashboard, track organ matching status, and manage your profile." />
      </Helmet>

      <Layout>
        <div className="min-h-screen py-12 px-4 flex items-center">
          <div className="container max-w-md mx-auto">
            {/* Header */}
            <div className="text-center mb-8">
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-4">
                <Shield className="w-4 h-4 text-primary" />
                <span className="text-sm font-medium text-primary">Secure Login</span>
              </div>
              <h1 className="text-3xl font-bold mb-2">Welcome Back</h1>
              <p className="text-muted-foreground">
                Access your JeevanBindu dashboard
              </p>
            </div>

            {/* Login Card */}
            <div className="bg-card rounded-2xl border border-border p-6 shadow-lg animate-scale-in">
              <Tabs value={activeTab} onValueChange={setActiveTab}>
                <TabsList className="grid w-full grid-cols-2 mb-6">
                  <TabsTrigger value="individual" className="gap-2">
                    <Fingerprint className="w-4 h-4" />
                    Individual
                  </TabsTrigger>
                  <TabsTrigger value="hospital" className="gap-2">
                    <Building2 className="w-4 h-4" />
                    Hospital/Admin
                  </TabsTrigger>
                </TabsList>

                {/* Individual Login (Aadhar + OTP) */}
                <TabsContent value="individual">
                  <form onSubmit={otpSent ? handleAadharLogin : handleSendOtp} className="space-y-6">
                    {/* User Type Selection */}
                    <div className="flex gap-2 mb-4">
                      <Button
                        type="button"
                        variant={userType === 'donor' ? 'default' : 'outline'}
                        size="sm"
                        className="flex-1"
                        onClick={() => setUserType('donor')}
                      >
                        Donor
                      </Button>
                      <Button
                        type="button"
                        variant={userType === 'recipient' ? 'default' : 'outline'}
                        size="sm"
                        className="flex-1"
                        onClick={() => setUserType('recipient')}
                      >
                        Recipient
                      </Button>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="aadhar-login">Aadhar Number</Label>
                      <Input
                        id="aadhar-login"
                        type="text"
                        placeholder="XXXX XXXX XXXX"
                        value={aadharNumber}
                        onChange={(e) => setAadharNumber(e.target.value.replace(/\D/g, '').slice(0, 12))}
                        className="text-lg tracking-widest"
                        disabled={otpSent}
                      />
                    </div>

                    {otpSent && (
                      <div className="space-y-2 animate-slide-up">
                        <Label htmlFor="otp-login">Enter OTP</Label>
                        <Input
                          id="otp-login"
                          type="text"
                          placeholder="XXXXXX"
                          value={otp}
                          onChange={(e) => setOtp(e.target.value.replace(/\D/g, '').slice(0, 6))}
                          className="text-lg tracking-widest"
                        />
                        <button
                          type="button"
                          className="text-xs text-primary hover:underline"
                          onClick={() => {
                            setOtpSent(false);
                            setOtp('');
                          }}
                        >
                          Change Aadhar Number
                        </button>
                      </div>
                    )}

                    <Button
                      type="submit"
                      className="w-full"
                      variant="hero"
                      size="lg"
                      disabled={isLoading || (!otpSent && aadharNumber.length !== 12)}
                    >
                      {isLoading ? (
                        <>
                          <Loader2 className="w-4 h-4 animate-spin" />
                          {otpSent ? 'Verifying...' : 'Sending OTP...'}
                        </>
                      ) : (
                        <>
                          {otpSent ? 'Login' : 'Send OTP'}
                          <ArrowRight className="w-4 h-4" />
                        </>
                      )}
                    </Button>
                  </form>

                  <div className="mt-6 text-center">
                    <p className="text-sm text-muted-foreground">
                      Not registered yet?{' '}
                      <button
                        onClick={() => navigate('/register')}
                        className="text-primary hover:underline font-medium"
                      >
                        Register Now
                      </button>
                    </p>
                  </div>
                </TabsContent>

                {/* Hospital/Admin Login (Email + Password) */}
                <TabsContent value="hospital">
                  <form onSubmit={handleHospitalLogin} className="space-y-6">
                    <div className="space-y-2">
                      <Label htmlFor="email">Email Address</Label>
                      <Input
                        id="email"
                        type="email"
                        placeholder="hospital@example.org"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="password">Password</Label>
                      <div className="relative">
                        <Input
                          id="password"
                          type={showPassword ? 'text' : 'password'}
                          placeholder="••••••••"
                          value={password}
                          onChange={(e) => setPassword(e.target.value)}
                          className="pr-10"
                        />
                        <button
                          type="button"
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                          onClick={() => setShowPassword(!showPassword)}
                        >
                          {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                      </div>
                    </div>

                    <div className="flex items-center justify-between text-sm">
                      <button type="button" className="text-primary hover:underline">
                        Forgot Password?
                      </button>
                    </div>

                    <Button
                      type="submit"
                      className="w-full"
                      variant="default"
                      size="lg"
                      disabled={isLoading}
                    >
                      {isLoading ? (
                        <>
                          <Loader2 className="w-4 h-4 animate-spin" />
                          Logging in...
                        </>
                      ) : (
                        <>
                          <Lock className="w-4 h-4" />
                          Login
                        </>
                      )}
                    </Button>
                  </form>

                  <div className="mt-6 p-4 rounded-lg bg-muted text-sm">
                    <p className="text-muted-foreground">
                      <strong>Demo Credentials:</strong>
                    </p>
                    <p className="text-muted-foreground mt-1">
                      Hospital: hospital@example.org / any password
                    </p>
                    <p className="text-muted-foreground">
                      Admin: admin@jeevanbindu.gov.in / any password
                    </p>
                  </div>
                </TabsContent>
              </Tabs>
            </div>
          </div>
        </div>
      </Layout>
    </>
  );
};

export default Login;
