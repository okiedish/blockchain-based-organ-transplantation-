import { Helmet } from 'react-helmet-async';
import Layout from '@/components/layout/Layout';
import { Card, CardContent } from '@/components/ui/card';
import { 
  Heart, 
  Shield, 
  Link as LinkIcon, 
  Fingerprint,
  Building2,
  Users,
  Target,
  Award,
  Lightbulb
} from 'lucide-react';

const features = [
  {
    icon: Fingerprint,
    title: 'Aadhar Integration',
    description: 'Secure identity verification through UIDAI ensures authentic registrations and prevents fraud.',
  },
  {
    icon: LinkIcon,
    title: 'Blockchain Powered',
    description: 'Ethereum blockchain records every transaction, ensuring immutability and transparency.',
  },
  {
    icon: Building2,
    title: 'Hospital Network',
    description: 'Connected with 1,250+ verified hospitals across India for seamless organ allocation.',
  },
  {
    icon: Shield,
    title: 'Data Security',
    description: 'End-to-end encryption, SSL certificates, and HIPAA-compliant data handling.',
  },
];

const teamMembers = [
  { name: 'Dr. Rajesh Kumar', role: 'Project Director', org: 'Ministry of Health' },
  { name: 'Dr. Priya Sharma', role: 'Medical Advisor', org: 'NOTTO' },
  { name: 'Amit Patel', role: 'Technical Lead', org: 'NIC' },
  { name: 'Dr. Sunita Devi', role: 'Transplant Specialist', org: 'AIIMS Delhi' },
];

const About = () => {
  return (
    <>
      <Helmet>
        <title>About JeevanBindu | India's National Organ Donation Registry</title>
        <meta name="description" content="Learn about JeevanBindu - India's blockchain-powered national organ donation registry. Our mission, architecture, team, and the technology behind transparent organ allocation." />
      </Helmet>

      <Layout>
        <div className="min-h-screen py-12">
          {/* Hero Section */}
          <section className="container mx-auto px-4 mb-20">
            <div className="max-w-4xl mx-auto text-center">
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-6">
                <Heart className="w-4 h-4 text-healthcare-red" />
                <span className="text-sm font-medium text-primary">About Us</span>
              </div>
              <h1 className="text-4xl md:text-5xl font-bold mb-6">
                Saving Lives Through <span className="text-gradient">Technology</span>
              </h1>
              <p className="text-xl text-muted-foreground mb-8">
                JeevanBindu is India's first blockchain-powered national organ donation registry, 
                built to bring transparency, security, and efficiency to organ allocation.
              </p>
            </div>
          </section>

          {/* Mission Section */}
          <section className="bg-muted/50 py-20 mb-20">
            <div className="container mx-auto px-4">
              <div className="grid lg:grid-cols-2 gap-12 items-center">
                <div>
                  <div className="flex items-center gap-2 mb-4">
                    <Target className="w-6 h-6 text-primary" />
                    <h2 className="text-3xl font-bold">Our Mission</h2>
                  </div>
                  <p className="text-muted-foreground mb-6">
                    To create a transparent, efficient, and corruption-free organ donation 
                    ecosystem in India by leveraging blockchain technology and government 
                    identity infrastructure.
                  </p>
                  <div className="space-y-4">
                    {[
                      'Eliminate middlemen and corruption in organ allocation',
                      'Provide real-time tracking for donors and recipients',
                      'Enable instant verification through Aadhar integration',
                      'Create an immutable audit trail for accountability',
                    ].map((point, index) => (
                      <div key={index} className="flex items-start gap-3">
                        <div className="w-6 h-6 rounded-full bg-healthcare-green/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <span className="text-healthcare-green text-sm">✓</span>
                        </div>
                        <p className="text-foreground">{point}</p>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="relative">
                  <div className="aspect-square max-w-md mx-auto bg-gradient-to-br from-primary/20 to-healthcare-teal/20 rounded-3xl flex items-center justify-center">
                    <div className="w-32 h-32 rounded-2xl gradient-primary shadow-glow flex items-center justify-center">
                      <Heart className="w-16 h-16 text-primary-foreground" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* Architecture Section */}
          <section className="container mx-auto px-4 mb-20">
            <div className="text-center mb-12">
              <div className="flex items-center justify-center gap-2 mb-4">
                <Lightbulb className="w-6 h-6 text-primary" />
                <h2 className="text-3xl font-bold">System Architecture</h2>
              </div>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                Built with modern technologies for security, scalability, and transparency
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {features.map((feature, index) => (
                <Card key={feature.title} className="animate-slide-up" style={{ animationDelay: `${index * 0.1}s` }}>
                  <CardContent className="pt-6">
                    <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-4">
                      <feature.icon className="w-6 h-6 text-primary" />
                    </div>
                    <h3 className="font-semibold mb-2">{feature.title}</h3>
                    <p className="text-sm text-muted-foreground">{feature.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Tech Stack */}
            <div className="mt-12 p-8 rounded-2xl bg-card border border-border">
              <h3 className="text-xl font-semibold mb-6 text-center">Technology Stack</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                {[
                  { label: 'Frontend', tech: 'React.js + Tailwind CSS' },
                  { label: 'Backend', tech: 'Node.js + Express.js' },
                  { label: 'Blockchain', tech: 'Ethereum (Smart Contracts)' },
                  { label: 'Database', tech: 'MongoDB / PostgreSQL' },
                  { label: 'Authentication', tech: 'Aadhar eKYC + JWT' },
                  { label: 'Security', tech: 'SSL + Password Hashing' },
                  { label: 'Hosting', tech: 'Netlify / Vercel' },
                  { label: 'Cloud DB', tech: 'MongoDB Atlas' },
                ].map((item) => (
                  <div key={item.label} className="text-center">
                    <p className="text-sm text-muted-foreground mb-1">{item.label}</p>
                    <p className="font-medium">{item.tech}</p>
                  </div>
                ))}
              </div>
            </div>
          </section>

          {/* Team Section */}
          <section className="bg-foreground text-primary-foreground py-20 mb-20">
            <div className="container mx-auto px-4">
              <div className="text-center mb-12">
                <div className="flex items-center justify-center gap-2 mb-4">
                  <Users className="w-6 h-6" />
                  <h2 className="text-3xl font-bold">Our Team & Guides</h2>
                </div>
                <p className="text-primary-foreground/70 max-w-2xl mx-auto">
                  JeevanBindu is developed by a dedicated team of healthcare professionals, 
                  technologists, and government officials.
                </p>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-4xl mx-auto">
                {teamMembers.map((member) => (
                  <div key={member.name} className="text-center">
                    <div className="w-20 h-20 rounded-full bg-primary/20 mx-auto mb-4 flex items-center justify-center">
                      <Award className="w-8 h-8 text-primary" />
                    </div>
                    <h4 className="font-semibold">{member.name}</h4>
                    <p className="text-sm text-primary-foreground/70">{member.role}</p>
                    <p className="text-xs text-primary-foreground/50">{member.org}</p>
                  </div>
                ))}
              </div>
            </div>
          </section>

          {/* Benefits Section */}
          <section className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              <h2 className="text-3xl font-bold mb-8 text-center">
                Benefits of Blockchain + Aadhar Integration
              </h2>
              <div className="grid md:grid-cols-2 gap-6">
                {[
                  {
                    title: 'Tamper-Proof Records',
                    description: 'Once data is recorded on the blockchain, it cannot be altered or deleted, ensuring complete integrity.',
                  },
                  {
                    title: 'Instant Verification',
                    description: 'Aadhar integration enables real-time identity verification, eliminating fake registrations.',
                  },
                  {
                    title: 'Smart Contract Automation',
                    description: 'Organ matching and allocation are automated through smart contracts, reducing human error and bias.',
                  },
                  {
                    title: 'Complete Transparency',
                    description: 'Every stakeholder can verify transactions, building trust in the system.',
                  },
                  {
                    title: 'Decentralized Security',
                    description: 'No single point of failure - data is distributed across the blockchain network.',
                  },
                  {
                    title: 'Audit Compliance',
                    description: 'Complete audit trail for regulatory compliance and accountability.',
                  },
                ].map((benefit) => (
                  <Card key={benefit.title}>
                    <CardContent className="pt-6">
                      <h4 className="font-semibold mb-2">{benefit.title}</h4>
                      <p className="text-sm text-muted-foreground">{benefit.description}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </section>
        </div>
      </Layout>
    </>
  );
};

export default About;
