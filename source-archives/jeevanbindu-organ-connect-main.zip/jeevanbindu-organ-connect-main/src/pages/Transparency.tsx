import { Helmet } from 'react-helmet-async';
import Layout from '@/components/layout/Layout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { 
  Eye,
  Heart,
  Users,
  Activity,
  Shield,
  Building2,
  TrendingUp,
  CheckCircle
} from 'lucide-react';
import { mockStatistics, mockHospitals, organTypes, bloodGroups } from '@/lib/mockData';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line } from 'recharts';

const COLORS = ['#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6', '#EC4899', '#06B6D4', '#84CC16'];

const Transparency = () => {
  const stateData = Object.entries(mockStatistics.donorsByState)
    .map(([state, count]) => ({ state, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 10);

  const organData = Object.entries(mockStatistics.organsByType)
    .map(([organ, count]) => ({ 
      name: organTypes.find(o => o.value === organ)?.label || organ, 
      value: count 
    }))
    .sort((a, b) => b.value - a.value);

  // Mock trend data
  const trendData = [
    { month: 'Jan', donors: 1200, recipients: 1800, matches: 350 },
    { month: 'Feb', donors: 1350, recipients: 1950, matches: 380 },
    { month: 'Mar', donors: 1500, recipients: 2100, matches: 420 },
    { month: 'Apr', donors: 1650, recipients: 2300, matches: 460 },
    { month: 'May', donors: 1800, recipients: 2500, matches: 510 },
    { month: 'Jun', donors: 2000, recipients: 2700, matches: 580 },
  ];

  // Public table data (anonymized)
  const publicTableData = organTypes.map((organ, index) => ({
    organ: organ.label,
    available: Math.floor(Math.random() * 500) + 100,
    bloodGroups: bloodGroups.slice(0, 4).join(', '),
    hospitals: Math.floor(Math.random() * 200) + 50,
    verified: true,
  }));

  return (
    <>
      <Helmet>
        <title>Transparency Dashboard | JeevanBindu - Public Organ Donation Statistics</title>
        <meta name="description" content="View real-time public statistics on organ donation in India. Transparent data on donors, recipients, and successful matches powered by blockchain." />
      </Helmet>

      <Layout>
        <div className="min-h-screen py-12">
          <div className="container mx-auto px-4">
            {/* Header */}
            <div className="text-center mb-12">
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-4">
                <Eye className="w-4 h-4 text-primary" />
                <span className="text-sm font-medium text-primary">Public Dashboard</span>
              </div>
              <h1 className="text-4xl font-bold mb-4">
                Transparency Dashboard
              </h1>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                Real-time anonymized statistics on India's organ donation ecosystem. 
                All data is verified and recorded on the Ethereum blockchain.
              </p>
            </div>

            {/* Stats Grid */}
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-12">
              <Card className="animate-slide-up">
                <CardContent className="pt-6 text-center">
                  <Heart className="w-8 h-8 text-healthcare-red mx-auto mb-2" />
                  <p className="text-3xl font-bold">{mockStatistics.totalDonors.toLocaleString()}</p>
                  <p className="text-sm text-muted-foreground">Total Donors</p>
                </CardContent>
              </Card>
              <Card className="animate-slide-up" style={{ animationDelay: '0.1s' }}>
                <CardContent className="pt-6 text-center">
                  <Users className="w-8 h-8 text-primary mx-auto mb-2" />
                  <p className="text-3xl font-bold">{mockStatistics.totalRecipients.toLocaleString()}</p>
                  <p className="text-sm text-muted-foreground">Recipients</p>
                </CardContent>
              </Card>
              <Card className="animate-slide-up" style={{ animationDelay: '0.2s' }}>
                <CardContent className="pt-6 text-center">
                  <Activity className="w-8 h-8 text-healthcare-green mx-auto mb-2" />
                  <p className="text-3xl font-bold">{mockStatistics.successfulMatches.toLocaleString()}</p>
                  <p className="text-sm text-muted-foreground">Successful Matches</p>
                </CardContent>
              </Card>
              <Card className="animate-slide-up" style={{ animationDelay: '0.3s' }}>
                <CardContent className="pt-6 text-center">
                  <TrendingUp className="w-8 h-8 text-healthcare-orange mx-auto mb-2" />
                  <p className="text-3xl font-bold">{mockStatistics.pendingMatches.toLocaleString()}</p>
                  <p className="text-sm text-muted-foreground">Pending Matches</p>
                </CardContent>
              </Card>
              <Card className="animate-slide-up" style={{ animationDelay: '0.4s' }}>
                <CardContent className="pt-6 text-center">
                  <Building2 className="w-8 h-8 text-healthcare-purple mx-auto mb-2" />
                  <p className="text-3xl font-bold">{mockStatistics.verifiedHospitals.toLocaleString()}</p>
                  <p className="text-sm text-muted-foreground">Verified Hospitals</p>
                </CardContent>
              </Card>
            </div>

            {/* Charts Row */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-12">
              {/* Trend Chart */}
              <Card>
                <CardHeader>
                  <CardTitle>Monthly Trends</CardTitle>
                  <CardDescription>Growth in registrations and matches over time</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-72">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={trendData}>
                        <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                        <XAxis dataKey="month" className="text-xs" />
                        <YAxis className="text-xs" />
                        <Tooltip 
                          contentStyle={{ 
                            backgroundColor: 'hsl(var(--card))',
                            borderColor: 'hsl(var(--border))',
                            borderRadius: '8px'
                          }}
                        />
                        <Line type="monotone" dataKey="donors" stroke="#10B981" strokeWidth={2} />
                        <Line type="monotone" dataKey="recipients" stroke="#3B82F6" strokeWidth={2} />
                        <Line type="monotone" dataKey="matches" stroke="#F59E0B" strokeWidth={2} />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                  <div className="flex justify-center gap-6 mt-4">
                    <div className="flex items-center gap-2 text-sm">
                      <div className="w-3 h-3 rounded-full bg-healthcare-green" />
                      <span>Donors</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <div className="w-3 h-3 rounded-full bg-primary" />
                      <span>Recipients</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <div className="w-3 h-3 rounded-full bg-healthcare-orange" />
                      <span>Matches</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Organ Distribution */}
              <Card>
                <CardHeader>
                  <CardTitle>Organ Type Distribution</CardTitle>
                  <CardDescription>Breakdown of pledged organs by type</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-72">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={organData}
                          cx="50%"
                          cy="50%"
                          innerRadius={60}
                          outerRadius={100}
                          paddingAngle={2}
                          dataKey="value"
                          label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                          labelLine={false}
                        >
                          {organData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip 
                          contentStyle={{ 
                            backgroundColor: 'hsl(var(--card))',
                            borderColor: 'hsl(var(--border))',
                            borderRadius: '8px'
                          }}
                        />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* State-wise Chart */}
            <Card className="mb-12">
              <CardHeader>
                <CardTitle>State-wise Donor Distribution</CardTitle>
                <CardDescription>Number of registered donors across Indian states</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={stateData} layout="vertical">
                      <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                      <XAxis type="number" className="text-xs" />
                      <YAxis type="category" dataKey="state" className="text-xs" width={100} />
                      <Tooltip 
                        contentStyle={{ 
                          backgroundColor: 'hsl(var(--card))',
                          borderColor: 'hsl(var(--border))',
                          borderRadius: '8px'
                        }}
                      />
                      <Bar dataKey="count" fill="hsl(var(--primary))" radius={[0, 4, 4, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            {/* Public Table */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="w-5 h-5" />
                  Public Organ Availability
                </CardTitle>
                <CardDescription>
                  Anonymized data on organ availability across verified hospitals
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="rounded-lg border border-border overflow-hidden">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Organ Type</TableHead>
                        <TableHead>Available</TableHead>
                        <TableHead>Blood Groups</TableHead>
                        <TableHead>Hospitals</TableHead>
                        <TableHead>Verified</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {publicTableData.map((row) => (
                        <TableRow key={row.organ}>
                          <TableCell className="font-medium">{row.organ}</TableCell>
                          <TableCell>
                            <Badge variant="secondary">{row.available}</Badge>
                          </TableCell>
                          <TableCell className="text-sm text-muted-foreground">{row.bloodGroups}</TableCell>
                          <TableCell>{row.hospitals}</TableCell>
                          <TableCell>
                            <CheckCircle className="w-5 h-5 text-healthcare-green" />
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>

            {/* Blockchain Verification Badge */}
            <div className="mt-12 text-center">
              <div className="inline-flex items-center gap-3 px-6 py-4 rounded-2xl bg-card border border-border">
                <Shield className="w-8 h-8 text-primary" />
                <div className="text-left">
                  <p className="font-semibold">Blockchain Verified Data</p>
                  <p className="text-sm text-muted-foreground">
                    All statistics are immutably recorded on Ethereum
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Layout>
    </>
  );
};

export default Transparency;
