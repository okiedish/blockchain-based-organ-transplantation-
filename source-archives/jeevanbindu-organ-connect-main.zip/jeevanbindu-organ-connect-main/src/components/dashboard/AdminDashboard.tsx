import { User } from '@/types';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { 
  Shield,
  Users,
  Heart,
  Building2,
  Activity,
  TrendingUp,
  FileText,
  Eye
} from 'lucide-react';
import { mockStatistics, mockBlockchainRecords, mockHospitals, organTypes } from '@/lib/mockData';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

interface AdminDashboardProps {
  user: User;
}

const COLORS = ['#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6', '#EC4899', '#06B6D4', '#84CC16'];

const AdminDashboard = ({ user }: AdminDashboardProps) => {
  const stateData = Object.entries(mockStatistics.donorsByState)
    .map(([state, count]) => ({ state: state.slice(0, 3), count, fullName: state }))
    .slice(0, 8);

  const organData = Object.entries(mockStatistics.organsByType)
    .map(([organ, count]) => ({ 
      name: organTypes.find(o => o.value === organ)?.label || organ, 
      value: count 
    }))
    .slice(0, 6);

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <Shield className="w-6 h-6 text-primary" />
            <h1 className="text-3xl font-bold">Government Admin Dashboard</h1>
          </div>
          <p className="text-muted-foreground">
            National overview of organ donation network and analytics
          </p>
        </div>
        <Badge variant="outline" className="gap-1 px-3 py-1 w-fit">
          <Shield className="w-3 h-3 text-healthcare-purple" />
          Admin Access
        </Badge>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-8">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-healthcare-teal/10 flex items-center justify-center">
                <Heart className="w-5 h-5 text-healthcare-teal" />
              </div>
              <div>
                <p className="text-2xl font-bold">{mockStatistics.totalDonors.toLocaleString()}</p>
                <p className="text-xs text-muted-foreground">Total Donors</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                <Users className="w-5 h-5 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold">{mockStatistics.totalRecipients.toLocaleString()}</p>
                <p className="text-xs text-muted-foreground">Recipients</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-healthcare-green/10 flex items-center justify-center">
                <Activity className="w-5 h-5 text-healthcare-green" />
              </div>
              <div>
                <p className="text-2xl font-bold">{mockStatistics.successfulMatches.toLocaleString()}</p>
                <p className="text-xs text-muted-foreground">Matches</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-healthcare-orange/10 flex items-center justify-center">
                <TrendingUp className="w-5 h-5 text-healthcare-orange" />
              </div>
              <div>
                <p className="text-2xl font-bold">{mockStatistics.pendingMatches.toLocaleString()}</p>
                <p className="text-xs text-muted-foreground">Pending</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-healthcare-purple/10 flex items-center justify-center">
                <Building2 className="w-5 h-5 text-healthcare-purple" />
              </div>
              <div>
                <p className="text-2xl font-bold">{mockStatistics.verifiedHospitals.toLocaleString()}</p>
                <p className="text-xs text-muted-foreground">Hospitals</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <Card>
          <CardHeader>
            <CardTitle>Donors by State</CardTitle>
            <CardDescription>Distribution of registered donors across India</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={stateData}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis dataKey="state" className="text-xs" />
                  <YAxis className="text-xs" />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'hsl(var(--card))',
                      borderColor: 'hsl(var(--border))',
                      borderRadius: '8px'
                    }}
                    formatter={(value, name, props) => [value, props.payload.fullName]}
                  />
                  <Bar dataKey="count" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Organs by Type</CardTitle>
            <CardDescription>Distribution of pledged organs</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={organData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={100}
                    paddingAngle={2}
                    dataKey="value"
                  >
                    {organData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'hsl(var(--card))',
                      borderColor: 'hsl(var(--border))',
                      borderRadius: '8px'
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="flex flex-wrap justify-center gap-2 mt-4">
              {organData.map((entry, index) => (
                <div key={entry.name} className="flex items-center gap-1 text-xs">
                  <div 
                    className="w-3 h-3 rounded-full" 
                    style={{ backgroundColor: COLORS[index % COLORS.length] }}
                  />
                  <span>{entry.name}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Audit Trail */}
      <Card className="mb-8">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5" />
            Blockchain Audit Trail
          </CardTitle>
          <CardDescription>
            Recent transactions recorded on the Ethereum blockchain
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="rounded-lg border border-border overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Transaction Hash</TableHead>
                  <TableHead>Action</TableHead>
                  <TableHead>Timestamp</TableHead>
                  <TableHead>Details</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {mockBlockchainRecords.map((record) => (
                  <TableRow key={record.txHash}>
                    <TableCell className="font-mono text-sm">
                      {record.txHash.slice(0, 10)}...{record.txHash.slice(-8)}
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className="capitalize">
                        {record.action}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {record.timestamp.toLocaleString('en-IN')}
                    </TableCell>
                    <TableCell className="text-muted-foreground text-sm">
                      {JSON.stringify(record.data).slice(0, 30)}...
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Hospitals */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Building2 className="w-5 h-5" />
            Verified Hospitals
          </CardTitle>
          <CardDescription>
            Top performing hospitals in the network
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="rounded-lg border border-border overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Hospital</TableHead>
                  <TableHead>Location</TableHead>
                  <TableHead>Donors</TableHead>
                  <TableHead>Recipients</TableHead>
                  <TableHead>Matches</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {mockHospitals.map((hospital) => (
                  <TableRow key={hospital.id}>
                    <TableCell className="font-medium">{hospital.name}</TableCell>
                    <TableCell>{hospital.location.city}, {hospital.location.state}</TableCell>
                    <TableCell>{hospital.totalDonors}</TableCell>
                    <TableCell>{hospital.totalRecipients}</TableCell>
                    <TableCell className="font-bold text-healthcare-green">{hospital.successfulMatches}</TableCell>
                    <TableCell>
                      <Badge className="bg-healthcare-green/10 text-healthcare-green">
                        Verified
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AdminDashboard;
