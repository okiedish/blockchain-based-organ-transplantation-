import { User } from '@/types';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  Shield, 
  CheckCircle, 
  Clock, 
  Heart,
  Users,
  Search,
  Activity
} from 'lucide-react';
import { toast } from 'sonner';
import { mockDonors } from '@/lib/mockData';

interface RecipientDashboardProps {
  user: User;
}

const RecipientDashboard = ({ user }: RecipientDashboardProps) => {
  const potentialDonors = mockDonors.filter(
    d => d.bloodGroup === user.bloodGroup && d.status === 'available'
  );

  const handleRequestMatch = (donorId: string) => {
    toast.success('Match request submitted! Smart contract triggered.');
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'available': return 'bg-healthcare-green/10 text-healthcare-green border-healthcare-green/20';
      case 'matched': return 'bg-primary/10 text-primary border-primary/20';
      case 'pending': return 'bg-healthcare-orange/10 text-healthcare-orange border-healthcare-orange/20';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold mb-2">Welcome, {user.name}</h1>
          <p className="text-muted-foreground">Track your organ matching status and find potential donors</p>
        </div>
        <Badge variant="outline" className="gap-1 px-3 py-1 w-fit">
          <Shield className="w-3 h-3 text-healthcare-green" />
          Aadhar Verified
        </Badge>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Allocation Status</CardDescription>
          </CardHeader>
          <CardContent>
            <Badge className={`text-base px-4 py-1 ${getStatusColor(user.status)}`}>
              {user.status === 'pending' && <Clock className="w-4 h-4 mr-1" />}
              {user.status === 'matched' && <CheckCircle className="w-4 h-4 mr-1" />}
              {user.status.charAt(0).toUpperCase() + user.status.slice(1)}
            </Badge>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Organ Needed</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {user.organType.map((organ) => (
                <Badge key={organ} variant="secondary" className="capitalize">
                  <Heart className="w-3 h-3 mr-1" />
                  {organ}
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Blood Group</CardDescription>
          </CardHeader>
          <CardContent>
            <span className="text-3xl font-bold text-healthcare-red">{user.bloodGroup}</span>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Potential Matches</CardDescription>
          </CardHeader>
          <CardContent>
            <span className="text-3xl font-bold text-primary">{potentialDonors.length}</span>
          </CardContent>
        </Card>
      </div>

      {/* Potential Donors */}
      <Card className="mb-8">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="w-5 h-5" />
            Potential Donors
          </CardTitle>
          <CardDescription>
            Compatible donors based on your blood group and organ requirement
          </CardDescription>
        </CardHeader>
        <CardContent>
          {potentialDonors.length > 0 ? (
            <div className="space-y-4">
              {potentialDonors.map((donor) => (
                <div
                  key={donor.id}
                  className="flex flex-col md:flex-row md:items-center justify-between p-4 rounded-lg border border-border hover:bg-muted/50 transition-colors gap-4"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                      <Heart className="w-6 h-6 text-primary" />
                    </div>
                    <div>
                      <p className="font-medium">{donor.name}</p>
                      <p className="text-sm text-muted-foreground">
                        {donor.location.city}, {donor.location.state}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="text-center">
                      <p className="text-xs text-muted-foreground">Blood</p>
                      <p className="font-bold text-healthcare-red">{donor.bloodGroup}</p>
                    </div>
                    <div className="text-center">
                      <p className="text-xs text-muted-foreground">Organ</p>
                      <p className="font-medium capitalize">{donor.organType.join(', ')}</p>
                    </div>
                    <Badge className={getStatusColor(donor.status)}>
                      {donor.status}
                    </Badge>
                    <Button size="sm" onClick={() => handleRequestMatch(donor.id)}>
                      <Activity className="w-4 h-4" />
                      Request Match
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              <Search className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>No compatible donors available at this time.</p>
              <p className="text-sm">We will notify you when a match is found.</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Profile Info */}
      <Card>
        <CardHeader>
          <CardTitle>Your Profile</CardTitle>
          <CardDescription>Your verified registration details</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div>
              <p className="text-sm text-muted-foreground">Aadhar Number</p>
              <p className="font-medium">{user.aadharNumber}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Phone</p>
              <p className="font-medium">{user.phone}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Location</p>
              <p className="font-medium">{user.location.city}, {user.location.state}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Hospital</p>
              <p className="font-medium">{user.location.hospital || 'Not specified'}</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default RecipientDashboard;
