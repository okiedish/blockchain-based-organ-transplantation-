import { User } from '@/types';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  Shield, 
  CheckCircle, 
  Clock, 
  Heart,
  ExternalLink,
  RefreshCw,
  FileText
} from 'lucide-react';
import { toast } from 'sonner';

interface DonorDashboardProps {
  user: User;
}

const DonorDashboard = ({ user }: DonorDashboardProps) => {
  const handleUpdateAvailability = () => {
    toast.success('Availability status updated!');
  };

  const handleViewBlockchain = () => {
    toast.info('Opening blockchain explorer...');
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'available': return 'bg-healthcare-green/10 text-healthcare-green border-healthcare-green/20';
      case 'matched': return 'bg-primary/10 text-primary border-primary/20';
      case 'pending': return 'bg-healthcare-orange/10 text-healthcare-orange border-healthcare-orange/20';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold mb-2">Welcome, {user.name}</h1>
          <p className="text-muted-foreground">Manage your organ donation status and records</p>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="outline" className="gap-1 px-3 py-1">
            <Shield className="w-3 h-3 text-healthcare-green" />
            Aadhar Verified
          </Badge>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Current Status</CardDescription>
          </CardHeader>
          <CardContent>
            <Badge className={`text-base px-4 py-1 ${getStatusColor(user.status)}`}>
              {user.status === 'available' && <CheckCircle className="w-4 h-4 mr-1" />}
              {user.status === 'pending' && <Clock className="w-4 h-4 mr-1" />}
              {user.status.charAt(0).toUpperCase() + user.status.slice(1)}
            </Badge>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Organs Pledged</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {user.organType.map((organ) => (
                <Badge key={organ} variant="secondary" className="capitalize">
                  <Heart className="w-3 h-3 mr-1" />
                  {organ}
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Blood Group</CardDescription>
          </CardHeader>
          <CardContent>
            <span className="text-3xl font-bold text-healthcare-red">{user.bloodGroup}</span>
          </CardContent>
        </Card>
      </div>

      {/* Profile Card */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="w-5 h-5" />
              Profile Information
            </CardTitle>
            <CardDescription>Your verified registration details</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-muted-foreground">Aadhar Number</p>
                <p className="font-medium">{user.aadharNumber}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Phone</p>
                <p className="font-medium">{user.phone}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Location</p>
                <p className="font-medium">{user.location.city}, {user.location.state}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Hospital</p>
                <p className="font-medium">{user.location.hospital || 'Not specified'}</p>
              </div>
            </div>
            <div className="pt-4 border-t border-border">
              <p className="text-sm text-muted-foreground mb-2">Registered on</p>
              <p className="font-medium">{user.createdAt.toLocaleDateString('en-IN', { 
                day: 'numeric', 
                month: 'long', 
                year: 'numeric' 
              })}</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="w-5 h-5" />
              Blockchain Record
            </CardTitle>
            <CardDescription>Your immutable registration record on Ethereum</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="p-4 rounded-lg bg-muted">
              <p className="text-xs text-muted-foreground mb-1">Transaction Hash</p>
              <p className="font-mono text-sm break-all">{user.blockchainTxHash}</p>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <CheckCircle className="w-4 h-4 text-healthcare-green" />
              <span className="text-muted-foreground">Verified on Ethereum Mainnet</span>
            </div>
            <Button variant="outline" className="w-full" onClick={handleViewBlockchain}>
              <ExternalLink className="w-4 h-4" />
              View on Etherscan
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Actions */}
      <div className="mt-8 flex flex-wrap gap-4">
        <Button variant="hero" onClick={handleUpdateAvailability}>
          <RefreshCw className="w-4 h-4" />
          Update Availability Status
        </Button>
        <Button variant="outline" onClick={handleViewBlockchain}>
          <ExternalLink className="w-4 h-4" />
          View My Blockchain Record
        </Button>
      </div>
    </div>
  );
};

export default DonorDashboard;
