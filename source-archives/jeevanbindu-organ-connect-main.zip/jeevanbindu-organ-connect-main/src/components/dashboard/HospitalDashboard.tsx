import { useState } from 'react';
import { User } from '@/types';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { 
  Building2,
  Users,
  Heart,
  Activity,
  Search,
  CheckCircle,
  XCircle,
  ExternalLink,
  Filter
} from 'lucide-react';
import { toast } from 'sonner';
import { mockDonors, mockRecipients, bloodGroups, organTypes } from '@/lib/mockData';

interface HospitalDashboardProps {
  user: User;
}

const HospitalDashboard = ({ user }: HospitalDashboardProps) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [bloodFilter, setBloodFilter] = useState<string>('all');
  const [organFilter, setOrganFilter] = useState<string>('all');
  const [activeTab, setActiveTab] = useState<'donors' | 'recipients'>('donors');

  const allUsers = activeTab === 'donors' ? mockDonors : mockRecipients;
  
  const filteredUsers = allUsers.filter(u => {
    const matchesSearch = u.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         u.location.city.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesBlood = bloodFilter === 'all' || u.bloodGroup === bloodFilter;
    const matchesOrgan = organFilter === 'all' || u.organType.includes(organFilter as any);
    return matchesSearch && matchesBlood && matchesOrgan;
  });

  const handleVerify = (userId: string) => {
    toast.success('User verified successfully!');
  };

  const handleApproveMatch = (userId: string) => {
    toast.success('Match approved! Smart contract executed.');
  };

  const handleMarkUnavailable = (userId: string) => {
    toast.info('User marked as unavailable.');
  };

  const handleViewBlockchain = (txHash: string) => {
    toast.info('Opening blockchain record...');
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'available': return 'bg-healthcare-green/10 text-healthcare-green';
      case 'matched': return 'bg-primary/10 text-primary';
      case 'pending': return 'bg-healthcare-orange/10 text-healthcare-orange';
      case 'unavailable': return 'bg-destructive/10 text-destructive';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <Building2 className="w-6 h-6 text-primary" />
            <h1 className="text-3xl font-bold">{user.name}</h1>
          </div>
          <p className="text-muted-foreground">Real-time organ allocation and management dashboard</p>
        </div>
        <Badge variant="outline" className="gap-1 px-3 py-1 w-fit">
          <CheckCircle className="w-3 h-3 text-healthcare-green" />
          Verified Hospital
        </Badge>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-healthcare-teal/10 flex items-center justify-center">
                <Heart className="w-6 h-6 text-healthcare-teal" />
              </div>
              <div>
                <p className="text-2xl font-bold">{mockDonors.length}</p>
                <p className="text-sm text-muted-foreground">Total Donors</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                <Users className="w-6 h-6 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold">{mockRecipients.length}</p>
                <p className="text-sm text-muted-foreground">Recipients</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-healthcare-green/10 flex items-center justify-center">
                <CheckCircle className="w-6 h-6 text-healthcare-green" />
              </div>
              <div>
                <p className="text-2xl font-bold">45</p>
                <p className="text-sm text-muted-foreground">Matches</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-healthcare-orange/10 flex items-center justify-center">
                <Activity className="w-6 h-6 text-healthcare-orange" />
              </div>
              <div>
                <p className="text-2xl font-bold">12</p>
                <p className="text-sm text-muted-foreground">Pending</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Table Card */}
      <Card>
        <CardHeader>
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <CardTitle>Patient Registry</CardTitle>
              <CardDescription>Manage donors and recipients in your hospital network</CardDescription>
            </div>
            <div className="flex gap-2">
              <Button
                variant={activeTab === 'donors' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setActiveTab('donors')}
              >
                <Heart className="w-4 h-4" />
                Donors
              </Button>
              <Button
                variant={activeTab === 'recipients' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setActiveTab('recipients')}
              >
                <Users className="w-4 h-4" />
                Recipients
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {/* Filters */}
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search by name or city..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={bloodFilter} onValueChange={setBloodFilter}>
              <SelectTrigger className="w-full md:w-32">
                <SelectValue placeholder="Blood" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Blood</SelectItem>
                {bloodGroups.map(bg => (
                  <SelectItem key={bg} value={bg}>{bg}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={organFilter} onValueChange={setOrganFilter}>
              <SelectTrigger className="w-full md:w-40">
                <SelectValue placeholder="Organ" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Organs</SelectItem>
                {organTypes.map(organ => (
                  <SelectItem key={organ.value} value={organ.value}>{organ.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Table */}
          <div className="rounded-lg border border-border overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Blood</TableHead>
                  <TableHead>Organ</TableHead>
                  <TableHead>Location</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Verified</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredUsers.map((u) => (
                  <TableRow key={u.id}>
                    <TableCell className="font-medium">{u.name}</TableCell>
                    <TableCell>
                      <Badge variant="outline" className="font-bold text-healthcare-red">
                        {u.bloodGroup}
                      </Badge>
                    </TableCell>
                    <TableCell className="capitalize">{u.organType.join(', ')}</TableCell>
                    <TableCell>{u.location.city}, {u.location.state}</TableCell>
                    <TableCell>
                      <Badge className={getStatusColor(u.status)}>
                        {u.status}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {u.isVerified ? (
                        <CheckCircle className="w-5 h-5 text-healthcare-green" />
                      ) : (
                        <XCircle className="w-5 h-5 text-muted-foreground" />
                      )}
                    </TableCell>
                    <TableCell>
                      <div className="flex justify-end gap-2">
                        {!u.isVerified && (
                          <Button size="sm" variant="outline" onClick={() => handleVerify(u.id)}>
                            Verify
                          </Button>
                        )}
                        {activeTab === 'recipients' && u.status === 'pending' && (
                          <Button size="sm" onClick={() => handleApproveMatch(u.id)}>
                            Approve Match
                          </Button>
                        )}
                        {u.status === 'available' && (
                          <Button size="sm" variant="ghost" onClick={() => handleMarkUnavailable(u.id)}>
                            <XCircle className="w-4 h-4" />
                          </Button>
                        )}
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => handleViewBlockchain(u.blockchainTxHash || '')}
                        >
                          <ExternalLink className="w-4 h-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          {filteredUsers.length === 0 && (
            <div className="text-center py-8 text-muted-foreground">
              <Filter className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>No results found with current filters.</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default HospitalDashboard;
